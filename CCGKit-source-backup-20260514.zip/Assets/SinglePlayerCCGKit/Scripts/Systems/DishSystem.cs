// Copyright (C) 2019 gamevanilla. All rights reserved.
// This code can only be used under the standard Unity Asset Store End User License Agreement,
// a copy of which is available at http://unity3d.com/company/legal/as_terms.

using System;
using UnityEngine;

namespace CCGKit
{
    /// <summary>
    /// Owns the active <see cref="DishProgress"/> for the current battle, applies ingredient cards,
    /// and tracks <b>heat</b> (increments each time the player ends a turn; too much heat fails the dish).
    /// Hook <see cref="OnPlayerTurnEnded"/> to the <c>PlayerTurnEnded</c> game event.
    /// </summary>
    public class DishSystem : MonoBehaviour
    {
        [Tooltip("When heat reaches or exceeds this value, the battle is lost (dish failed).")]
        [SerializeField]
        private int heatFailAt = 3;

        private DishProgress _progress;
        private bool _dishWon;
        private bool _endedByHeat;
        private bool _endedBySuitOverflow;
        private int _heat;

        public DishProgress Progress => _progress;
        public bool HasActiveDish => _progress != null;
        public int CurrentHeat => _heat;
        public int HeatFailAt => heatFailAt;

        /// <summary>Invoked after dish init or each ingredient; <paramref name="playedCard"/> is null on init.</summary>
        public event Action<DishProgress, CardTemplate> DishStateVisualChanged;

        /// <summary>Current heat vs fail threshold (lose when current reaches <paramref name="maxHeat"/>).</summary>
        public event Action<int, int> HeatChanged;

        public void InitializeWithDish(Dish dish)
        {
            _dishWon = false;
            _endedByHeat = false;
            _endedBySuitOverflow = false;
            _heat = 0;
            if (dish == null)
            {
                _progress = null;
                RaiseDishVisual(null, null);
                NotifyHeat();
                return;
            }

            _progress = new DishProgress(dish);
            RaiseDishVisual(_progress, null);
            NotifyHeat();
        }

        /// <summary>Call when a card is played: adds its <see cref="CardTemplate.Suit"/> and <see cref="CardTemplate.Value"/>.</summary>
        public void RegisterIngredientPlayed(CardTemplate card)
        {
            if (card == null || _progress == null || _dishWon || _endedByHeat || _endedBySuitOverflow)
                return;

            _progress.ApplyIngredient(card.Suit, card.Value);
            RaiseDishVisual(_progress, card);
            if (_progress.TryGetFirstSuitOverTarget(out var overSuit, out var overTotal, out var overTarget))
            {
                _endedBySuitOverflow = true;
                var death = UnityEngine.Object.FindFirstObjectByType<CharacterDeathSystem>();
                if (death != null)
                    death.OnDishSuitOverTarget(overSuit, overTotal, overTarget);
                return;
            }

            if (_progress.IsComplete)
            {
                _dishWon = true;
                CompleteDish();
            }
        }

        private void CompleteDish()
        {
            var death = UnityEngine.Object.FindFirstObjectByType<CharacterDeathSystem>();
            if (death != null)
                death.OnDishComplete();
        }

        /// <summary>Called from <c>PlayerTurnEnded</c> (end of the player’s turn, before the enemy / kitchen step).</summary>
        public void OnPlayerTurnEnded()
        {
            if (_progress == null || _dishWon || _endedByHeat || _endedBySuitOverflow)
                return;

            _heat++;
            NotifyHeat();
            if (_heat < heatFailAt)
                return;

            _endedByHeat = true;
            var death = UnityEngine.Object.FindFirstObjectByType<CharacterDeathSystem>();
            if (death != null)
                death.OnDishOverheated();
        }

        private void RaiseDishVisual(DishProgress progress, CardTemplate playedCard)
        {
            DishStateVisualChanged?.Invoke(progress, playedCard);
        }

        private void NotifyHeat()
        {
            HeatChanged?.Invoke(_heat, heatFailAt);
        }
    }
}
