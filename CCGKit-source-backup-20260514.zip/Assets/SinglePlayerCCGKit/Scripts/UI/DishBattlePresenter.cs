// Copyright (C) 2019 gamevanilla. All rights reserved.
// This code can only be used under the standard Unity Asset Store End User License Agreement,
// a copy of which is available at http://unity3d.com/company/legal/as_terms.

using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace CCGKit
{
    /// <summary>
    /// Builds a simple modular battle UI: central dish art, four suit target badges in a diamond, and a plate log.
    /// Wires to <see cref="DishSystem"/> events. Assign <see cref="canvasOverride"/> in the inspector to parent under a specific canvas.
    /// </summary>
    public class DishBattlePresenter : MonoBehaviour
    {
#pragma warning disable 649
        [Tooltip("If set, the dish panel is parented here; otherwise the first Screen Space - Camera canvas named \"Canvas\" is used.")]
        [SerializeField]
        private Canvas canvasOverride;

        [Tooltip("Optional; defaults to Resources sprite \"BattleDishArt\".")]
        [SerializeField]
        private Sprite dishSpriteOverride;

        [Tooltip("Optional TMP font; defaults to TMP_Settings.defaultFontAsset.")]
        [SerializeField]
        private TMP_FontAsset fontOverride;
#pragma warning restore 649

        private DishSystem _dishSystem;
        private TMP_FontAsset _font;
        private SuitTargetBadgeView[] _badges;
        private DishPlateIngredientLog _plateLog;
        private RectTransform _root;

        private void Awake()
        {
            _dishSystem = GetComponent<DishSystem>();
            if (_dishSystem == null)
                _dishSystem = FindFirstObjectByType<DishSystem>();

            _font = fontOverride != null ? fontOverride : TMP_Settings.defaultFontAsset;
            BuildUi();
            if (_dishSystem != null)
                _dishSystem.DishStateVisualChanged += OnDishStateVisualChanged;
        }

        private void OnDestroy()
        {
            if (_dishSystem != null)
                _dishSystem.DishStateVisualChanged -= OnDishStateVisualChanged;
        }

        private void BuildUi()
        {
            var canvas = canvasOverride != null ? canvasOverride : FindBattleCanvas();
            if (canvas == null)
            {
                Debug.LogWarning("DishBattlePresenter: no canvas found.");
                return;
            }

            var rootGo = new GameObject("DishBattlePanel", typeof(RectTransform));
            _root = rootGo.GetComponent<RectTransform>();
            _root.SetParent(canvas.transform, false);
            _root.anchorMin = new Vector2(1f, 0.5f);
            _root.anchorMax = new Vector2(1f, 0.5f);
            _root.pivot = new Vector2(1f, 0.5f);
            _root.anchoredPosition = new Vector2(-32f, 72f);
            _root.sizeDelta = new Vector2(480f, 520f);

            var dishSprite = dishSpriteOverride != null ? dishSpriteOverride : Resources.Load<Sprite>("BattleDishArt");
            var dishGo = new GameObject("DishImage", typeof(RectTransform), typeof(Image));
            dishGo.transform.SetParent(_root, false);
            var dishRt = dishGo.GetComponent<RectTransform>();
            dishRt.anchorMin = dishRt.anchorMax = dishRt.pivot = new Vector2(0.5f, 0.5f);
            dishRt.anchoredPosition = new Vector2(-120f, 24f);
            dishRt.sizeDelta = new Vector2(340f, 240f);
            var dishImg = dishGo.GetComponent<Image>();
            dishImg.sprite = dishSprite;
            dishImg.preserveAspect = true;
            dishImg.raycastTarget = false;
            dishImg.color = dishSprite != null ? Color.white : new Color(0.25f, 0.22f, 0.2f, 0.85f);

            _badges = new SuitTargetBadgeView[4];
            _badges[(int)IngredientSuit.Sweet] = CreateBadge(_root, new Vector2(-120f, 168f), new Vector2(148f, 96f), IngredientSuit.Sweet);
            _badges[(int)IngredientSuit.Salty] = CreateBadge(_root, new Vector2(-268f, 24f), new Vector2(148f, 96f), IngredientSuit.Salty);
            _badges[(int)IngredientSuit.Sour] = CreateBadge(_root, new Vector2(28f, 24f), new Vector2(148f, 96f), IngredientSuit.Sour);
            _badges[(int)IngredientSuit.Bitter] = CreateBadge(_root, new Vector2(-120f, -128f), new Vector2(148f, 96f), IngredientSuit.Bitter);

            var plateGo = new GameObject("PlateLog", typeof(RectTransform), typeof(Image));
            plateGo.transform.SetParent(_root, false);
            var plateRt = plateGo.GetComponent<RectTransform>();
            plateRt.anchorMin = new Vector2(0.5f, 0f);
            plateRt.anchorMax = new Vector2(0.5f, 0f);
            plateRt.pivot = new Vector2(0.5f, 0f);
            plateRt.anchoredPosition = new Vector2(-120f, 8f);
            plateRt.sizeDelta = new Vector2(320f, 120f);
            var plateBg = plateGo.GetComponent<Image>();
            plateBg.color = new Color(0f, 0f, 0f, 0.35f);
            plateBg.raycastTarget = false;

            var contentGo = new GameObject("Content", typeof(RectTransform));
            contentGo.transform.SetParent(plateGo.transform, false);
            var contentRt = contentGo.GetComponent<RectTransform>();
            contentRt.anchorMin = Vector2.zero;
            contentRt.anchorMax = Vector2.one;
            contentRt.offsetMin = Vector2.zero;
            contentRt.offsetMax = Vector2.zero;
            var contentVlg = contentGo.AddComponent<VerticalLayoutGroup>();
            contentVlg.childAlignment = TextAnchor.UpperLeft;
            contentVlg.childControlHeight = true;
            contentVlg.childControlWidth = true;
            contentVlg.childForceExpandWidth = true;
            contentVlg.spacing = 0f;

            _plateLog = plateGo.AddComponent<DishPlateIngredientLog>();
            _plateLog.Configure(contentRt, _font);

            RefreshAll(null, null);
        }

        private static Canvas FindBattleCanvas()
        {
            var canvases = FindObjectsOfType<Canvas>();
            foreach (var c in canvases)
            {
                if (c.renderMode != RenderMode.ScreenSpaceCamera)
                    continue;
                if (c.gameObject.name == "Canvas")
                    return c;
            }

            foreach (var c in canvases)
            {
                if (c.renderMode == RenderMode.ScreenSpaceCamera)
                    return c;
            }

            return canvases.Length > 0 ? canvases[0] : null;
        }

        private SuitTargetBadgeView CreateBadge(RectTransform parent, Vector2 anchoredPosition, Vector2 size, IngredientSuit suit)
        {
            var go = new GameObject("Badge_" + suit, typeof(RectTransform));
            go.transform.SetParent(parent, false);
            var rt = go.GetComponent<RectTransform>();
            rt.anchorMin = rt.anchorMax = rt.pivot = new Vector2(0.5f, 0.5f);
            rt.anchoredPosition = anchoredPosition;
            rt.sizeDelta = size;

            var bg = go.AddComponent<Image>();
            bg.raycastTarget = false;
            bg.color = Color.white;

            var vlg = go.AddComponent<VerticalLayoutGroup>();
            vlg.padding = new RectOffset(4, 4, 4, 4);
            vlg.spacing = 0f;
            vlg.childAlignment = TextAnchor.MiddleCenter;
            vlg.childControlHeight = true;
            vlg.childControlWidth = true;
            vlg.childForceExpandWidth = true;

            var icon = CreateTmpLine(go.transform, "Icon", 30f, FontStyles.Normal);
            var name = CreateTmpLine(go.transform, "Suit", 14f, FontStyles.Bold);
            var val = CreateTmpLine(go.transform, "Value", 24f, FontStyles.Bold);

            var view = go.AddComponent<SuitTargetBadgeView>();
            view.Configure(bg, icon, name, val);
            return view;
        }

        private TextMeshProUGUI CreateTmpLine(Transform parent, string name, float height, FontStyles style)
        {
            var row = new GameObject(name, typeof(RectTransform));
            row.transform.SetParent(parent, false);
            var le = row.AddComponent<LayoutElement>();
            le.preferredHeight = height;
            le.minHeight = height;
            le.flexibleWidth = 1f;

            var tmp = row.AddComponent<TextMeshProUGUI>();
            if (_font != null)
                tmp.font = _font;
            tmp.fontSize = height - 2f;
            tmp.fontStyle = style;
            tmp.alignment = TextAlignmentOptions.Center;
            tmp.enableWordWrapping = false;
            tmp.raycastTarget = false;
            tmp.color = Color.white;
            return tmp;
        }

        private void OnDishStateVisualChanged(DishProgress progress, CardTemplate playedCard)
        {
            RefreshAll(progress, playedCard);
        }

        private void RefreshAll(DishProgress progress, CardTemplate playedCard)
        {
            if (_badges == null)
                return;

            if (progress == null)
            {
                foreach (var b in _badges)
                {
                    if (b != null)
                        b.SetActive(false);
                }

                if (_plateLog != null)
                    _plateLog.Clear();
                return;
            }

            if (playedCard == null && _plateLog != null)
                _plateLog.Clear();

            for (var i = 0; i < 4; i++)
            {
                var suit = (IngredientSuit)i;
                var target = progress.GetTarget(suit);
                var badge = _badges[i];
                if (badge == null)
                    continue;
                if (target <= 0)
                {
                    badge.SetActive(false);
                    continue;
                }

                badge.SetActive(true);
                badge.Bind(suit, progress.GetTotal(suit), target);
            }

            if (playedCard != null && _plateLog != null)
                _plateLog.Append(playedCard, _font);
        }
    }
}
