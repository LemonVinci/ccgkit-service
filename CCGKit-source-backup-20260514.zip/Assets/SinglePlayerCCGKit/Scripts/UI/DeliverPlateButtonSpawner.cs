// Copyright (C) 2019 gamevanilla. All rights reserved.
// This code can only be used under the standard Unity Asset Store End User License Agreement,
// a copy of which is available at http://unity3d.com/company/legal/as_terms.

using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace CCGKit
{
    /// <summary>
    /// Clones the End Turn button visuals to create a "Deliver the plate" action button.
    /// Delivery succeeds only if the current overall dish approximation is at least the required threshold.
    /// </summary>
    public class DeliverPlateButtonSpawner : MonoBehaviour
    {
#pragma warning disable 649
        [SerializeField]
        private float requiredApproximationPercent = 85.0f;

        [SerializeField]
        private Vector2 clonedButtonOffset = new Vector2(-380.0f, 0.0f);
#pragma warning restore 649

        private void Start()
        {
            var endTurn = FindFirstObjectByType<EndTurnButton>();
            if (endTurn == null)
                return;

            var clone = Instantiate(endTurn.gameObject, endTurn.transform.parent);
            clone.name = "DeliverPlateButton";

            var rt = clone.GetComponent<RectTransform>();
            if (rt != null)
                rt.anchoredPosition += clonedButtonOffset;

            var label = clone.GetComponentInChildren<TextMeshProUGUI>(true);
            if (label != null)
                label.text = "Deliver the plate";

            var button = clone.GetComponent<Button>();
            if (button != null)
            {
                button.onClick.RemoveAllListeners();
                var handler = clone.AddComponent<DeliverPlateButton>();
                handler.Initialize(requiredApproximationPercent);
                button.onClick.AddListener(handler.OnButtonPressed);
            }

            var oldEndTurn = clone.GetComponent<EndTurnButton>();
            if (oldEndTurn != null)
                Destroy(oldEndTurn);
        }
    }

    /// <summary>
    /// Behaviour for the cloned Deliver Plate button.
    /// </summary>
    public class DeliverPlateButton : MonoBehaviour
    {
        private float requiredApproximation01;
        private HandPresentationSystem handPresentationSystem;
        private CardWithArrowSelectionSystem cardWithArrowSelectionSystem;
        private CardWithoutArrowSelectionSystem cardWithoutArrowSelectionSystem;

        public void Initialize(float requiredApproximationPercent)
        {
            requiredApproximation01 = Mathf.Clamp01(requiredApproximationPercent / 100.0f);
        }

        private void Start()
        {
            handPresentationSystem = FindFirstObjectByType<HandPresentationSystem>();
            cardWithArrowSelectionSystem = FindFirstObjectByType<CardWithArrowSelectionSystem>();
            cardWithoutArrowSelectionSystem = FindFirstObjectByType<CardWithoutArrowSelectionSystem>();
        }

        public void OnButtonPressed()
        {
            if (handPresentationSystem != null && handPresentationSystem.IsAnimating())
                return;

            if ((cardWithArrowSelectionSystem != null && cardWithArrowSelectionSystem.HasSelectedCard()) ||
                (cardWithoutArrowSelectionSystem != null && cardWithoutArrowSelectionSystem.HasSelectedCard()))
                return;

            var turn = FindFirstObjectByType<TurnManagementSystem>();
            if (turn != null && turn.IsEndOfGame())
                return;

            var dishSystem = FindFirstObjectByType<DishSystem>();
            var progress = dishSystem != null ? dishSystem.Progress : null;
            if (progress == null || progress.SourceDish == null)
                return;

            var approximation = DishScoring.ComputeAverage(progress.SourceDish, progress);
            if (approximation < requiredApproximation01)
            {
                Debug.Log(
                    $"DeliverPlateButton: approximation {Mathf.RoundToInt(approximation * 100f)}% is below required {Mathf.RoundToInt(requiredApproximation01 * 100f)}%.");
                return;
            }

            var death = FindFirstObjectByType<CharacterDeathSystem>();
            if (death != null)
                death.OnDishComplete();
        }
    }
}
